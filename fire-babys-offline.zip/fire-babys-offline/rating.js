/* Fire Babys star rating — OFFLINE STUB.
 *
 * Replaces rating.js ONLY inside the downloadable offline package.
 * No shipped page loads rating.js (the star-rating widget was removed
 * from every game by Jeff's order in Oct 2026); the file is carried only
 * so the package tree matches the site tree. The original talked to a
 * server, so this stub replaces it: no network calls, no widget, no
 * errors. Ratings in the offline edition simply do not exist.
 */
(function () {
  "use strict";
  window.FireBabysRating = {
    offline: true,
    rate: function () {
      return false;
    },
    getRating: function () {
      return null;
    },
  };
})();
