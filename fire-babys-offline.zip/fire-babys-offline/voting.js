/* Fire Babys voting — OFFLINE STUB.
 *
 * Replaces voting.js ONLY inside the downloadable offline package.
 * The real voting system is server-based (it talks to the vote worker),
 * and game voting was removed from the games by Jeff's order in Oct 2026;
 * arcade.html is the only page that still loads this file. Offline there
 * is nothing to vote against and no server to reach, so this stub simply
 * does nothing: no network calls, no banner, no errors. The page works
 * exactly as if the voting banner were absent.
 */
(function () {
  "use strict";
  window.FireBabysVoting = {
    offline: true,
    getCounts: function () {
      return null;
    },
    vote: function () {
      return false;
    },
  };
})();
