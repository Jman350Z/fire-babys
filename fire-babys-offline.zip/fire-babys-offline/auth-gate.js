/* Fire Babys LOCAL gate — OFFLINE EDITION replacement for auth-gate.js.
 *
 * Used ONLY inside the downloadable offline package. The online site keeps
 * using the real server auth-gate.js; this file never ships to .deploy.
 *
 * Same look, same public API as the server gate:
 *   window.FireBabysAuth.getUser()      -> {name, email:"", local:true} | null
 *   window.FireBabysAuth.getToken()     -> string | null
 *   window.FireBabysAuth.isAuthed()     -> bool
 *   window.FireBabysAuth.signOut()      -> clears session, re-shows gate
 *   window.FireBabysAuth.onAuthed(cb)   -> cb(user) now or when profile chosen
 *   Event: document 'fb-authed' with detail {name, email, local}
 *
 * Difference: there is no server and no email. "Sign in" = create or choose
 * a LOCAL player profile (a Fire Tamer name) stored in localStorage on this
 * device only. Zero network calls are made by this file.
 *
 * localStorage keys (same names as the online gate so game code that reads
 * them keeps working): fb_auth_token, fb_auth_user. Offline-only extra key:
 * fb_local_profiles = [{name, created}] — every profile made on this device.
 */
(function () {
  "use strict";

  var TOKEN_KEY = "fb_auth_token";
  var USER_KEY = "fb_auth_user";
  var PROFILES_KEY = "fb_local_profiles";

  var scripts = document.getElementsByTagName("script");
  var thisScript = scripts[scripts.length - 1];
  var qs = new URLSearchParams(window.location.search || "");
  var SHOW_BADGE =
    (thisScript && thisScript.getAttribute("data-badge") === "1") ||
    qs.get("badge") === "1";

  // ---- storage (defensive: file:// storage can be restricted) ----
  var memFallback = {};
  function store(key, val) {
    try {
      if (val === null) localStorage.removeItem(key);
      else localStorage.setItem(key, val);
    } catch (e) {
      if (val === null) delete memFallback[key];
      else memFallback[key] = val;
    }
  }
  function read(key) {
    try {
      var v = localStorage.getItem(key);
      return v !== null ? v : memFallback[key] || null;
    } catch (e) {
      return memFallback[key] || null;
    }
  }

  function getToken() {
    return read(TOKEN_KEY);
  }
  function getProfiles() {
    try {
      var p = JSON.parse(read(PROFILES_KEY) || "[]");
      return Object.prototype.toString.call(p) === "[object Array]" ? p : [];
    } catch (e) {
      return [];
    }
  }
  function saveProfile(name) {
    var profiles = getProfiles();
    for (var i = 0; i < profiles.length; i++) {
      if (profiles[i].name === name) return profiles[i];
    }
    var prof = { name: name, created: Date.now() };
    profiles.push(prof);
    store(PROFILES_KEY, JSON.stringify(profiles));
    return prof;
  }

  // ---- state ----
  var authedUser = null;
  var authedCbs = [];
  var gateEl = null;

  function setUser(u) {
    authedUser = u;
    if (u) store(USER_KEY, JSON.stringify(u));
    else store(USER_KEY, null);
  }

  // ---- page cloak: hide content until a profile is chosen ----
  var htmlEl = document.documentElement;
  var prevVisibility = htmlEl.style.visibility;
  htmlEl.style.visibility = "hidden";
  function uncloak() {
    htmlEl.style.visibility = prevVisibility;
  }

  // ---- gate UI (same visual design as the online gate) ----
  var CSS = [
    ".fbgate{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;",
    "background:radial-gradient(ellipse at 50% 0%,rgba(255,106,26,.28),transparent 60%),rgba(12,5,2,.97);",
    "visibility:visible;padding:20px;box-sizing:border-box;overflow-y:auto;-webkit-overflow-scrolling:touch;}",
    ".fbgate-card{width:100%;max-width:420px;background:rgba(26,13,6,.92);border:2px solid rgba(255,140,46,.55);",
    "border-radius:22px;padding:34px 30px;text-align:center;box-shadow:0 0 80px rgba(255,90,20,.3);}",
    ".fbgate-logo{font-size:44px;font-weight:900;letter-spacing:3px;line-height:1.05;margin:0 0 6px;",
    "background:linear-gradient(180deg,#fff7c0 5%,#ffd76a 30%,#ff8c2e 62%,#e8352c 100%);",
    "-webkit-background-clip:text;background-clip:text;color:transparent;}",
    ".fbgate-h{color:#ffd9ae;font-size:20px;font-weight:800;margin:10px 0 4px;letter-spacing:1px;}",
    ".fbgate-sub{color:#d8b89a;font-size:14px;margin:0 0 22px;line-height:1.5;}",
    ".fbgate label{display:block;text-align:left;color:#ffd9ae;font-size:13px;font-weight:700;margin:12px 0 6px;}",
    ".fbgate input{width:100%;box-sizing:border-box;padding:14px 16px;font-size:16px;border-radius:14px;",
    "border:2px solid rgba(255,140,46,.4);background:rgba(0,0,0,.45);color:#ffe9d6;outline:none;}",
    ".fbgate input:focus{border-color:#ff8c2e;box-shadow:0 0 0 3px rgba(255,140,46,.25);}",
    ".fbgate-btn{display:block;width:100%;margin-top:20px;padding:16px;border:none;border-radius:18px;cursor:pointer;",
    "font-size:18px;font-weight:900;letter-spacing:2px;color:#2a1206;",
    "background:linear-gradient(180deg,#ffd76a,#ff8c2e);box-shadow:0 6px 0 #a33c10,0 10px 24px rgba(255,106,26,.35);}",
    ".fbgate-btn:active{transform:translateY(3px);box-shadow:0 2px 0 #a33c10;}",
    ".fbgate-prof{display:block;width:100%;margin-top:10px;padding:13px;border:2px solid rgba(255,255,255,.35);border-radius:18px;cursor:pointer;",
    "font-size:16px;font-weight:800;color:#1a1a1a;background:#ffffff;text-align:center;}",
    ".fbgate-prof:hover{background:#f0f0f0;}",
    ".fbgate-div{display:flex;align-items:center;gap:12px;margin:18px 0 4px;color:#a8815e;font-size:12px;font-weight:700;}",
    ".fbgate-div::before,.fbgate-div::after{content:'';flex:1;height:1px;background:rgba(255,140,46,.3);}",
    ".fbgate-err{display:none;margin-top:14px;padding:10px 14px;border-radius:12px;font-size:14px;font-weight:700;",
    "color:#ffd2c2;background:rgba(232,53,44,.18);border:1px solid rgba(232,53,44,.5);}",
    ".fbgate-fine{margin-top:18px;font-size:12px;color:#a8815e;line-height:1.6;}",
    ".fbbadge{position:fixed;left:10px;bottom:10px;z-index:2147483646;display:flex;align-items:center;gap:8px;",
    "background:rgba(26,13,6,.9);border:1px solid rgba(255,140,46,.5);border-radius:999px;padding:6px 12px;",
    "color:#ffd9ae;font-size:12px;font-weight:700;cursor:pointer;visibility:visible;}",
    ".fbbadge small{color:#a8815e;font-weight:400;}",
  ].join("");

  function esc(s) {
    return String(s).replace(/[<>\"'&]/g, "");
  }

  function buildGate() {
    var style = document.createElement("style");
    style.textContent = CSS;
    document.head.appendChild(style);

    var profiles = getProfiles();
    var el = document.createElement("div");
    el.className = "fbgate";
    var html =
      '<div class="fbgate-card">' +
      '<div class="fbgate-logo">FIRE<br>BABYS</div>' +
      '<div class="fbgate-h">WHO\'S PLAYING?</div>' +
      '<p class="fbgate-sub">This offline edition keeps your player profile right here on this device. No internet, no email, no account.</p>';

    if (profiles.length) {
      html += '<div id="fbgate-profiles">';
      for (var i = 0; i < profiles.length; i++) {
        html +=
          '<button type="button" class="fbgate-prof" data-name="' +
          esc(profiles[i].name) +
          '">🔥 Play as ' +
          esc(profiles[i].name) +
          "</button>";
      }
      html += "</div>" + '<div class="fbgate-div">OR</div>';
    }

    html +=
      '<form id="fbgate-form" autocomplete="off">' +
      '<label for="fbgate-name">New Fire Tamer name</label>' +
      '<input id="fbgate-name" type="text" name="name" maxlength="40" placeholder="BlazeFan42" autocomplete="nickname" />' +
      '<button class="fbgate-btn" type="submit">START PLAYING</button>' +
      '<div class="fbgate-err" role="alert"></div>' +
      "</form>" +
      '<p class="fbgate-fine">Profiles and progress are saved only on this device.<br>Kids: ask a grown-up first.</p>' +
      "</div>";

    el.innerHTML = html;

    var profHost = el.querySelector("#fbgate-profiles");
    if (profHost) {
      var btns = profHost.querySelectorAll(".fbgate-prof");
      for (var j = 0; j < btns.length; j++) {
        btns[j].addEventListener("click", function () {
          chooseProfile(this.getAttribute("data-name"));
        });
      }
    }

    el.querySelector("#fbgate-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var name = el.querySelector("#fbgate-name").value.trim();
      var err = el.querySelector(".fbgate-err");
      if (!name) {
        err.textContent = "Pick a Fire Tamer name first!";
        err.style.display = "block";
        return;
      }
      saveProfile(name);
      chooseProfile(name);
    });

    document.body.appendChild(el);
    gateEl = el;
    return el;
  }

  function chooseProfile(name) {
    store(TOKEN_KEY, "local-" + Date.now().toString(36));
    finishAuth({ name: name, email: "", local: true });
  }

  function removeGate() {
    if (gateEl && gateEl.parentNode) gateEl.parentNode.removeChild(gateEl);
    gateEl = null;
  }

  function showBadge(user) {
    if (!SHOW_BADGE) return;
    var b = document.createElement("div");
    b.className = "fbbadge";
    b.title = "Playing as " + user.name + " — tap to switch player";
    var label = document.createElement("span");
    label.textContent = "🔥 " + user.name;
    var out = document.createElement("small");
    out.textContent = "switch player";
    b.appendChild(label);
    b.appendChild(out);
    b.addEventListener("click", function () {
      window.FireBabysAuth.signOut();
    });
    document.body.appendChild(b);
  }

  function finishAuth(user) {
    setUser(user);
    removeGate();
    uncloak();
    showBadge(user);
    authedCbs.splice(0).forEach(function (cb) {
      try {
        cb(user);
      } catch (e) {}
    });
    try {
      document.dispatchEvent(new CustomEvent("fb-authed", { detail: user }));
    } catch (e) {}
  }

  // ---- boot ----
  function boot() {
    var cached = null;
    try {
      cached = JSON.parse(read(USER_KEY) || "null");
    } catch (e) {}
    if (cached && cached.name) {
      if (!getToken()) store(TOKEN_KEY, "local-" + Date.now().toString(36));
      finishAuth({ name: cached.name, email: cached.email || "", local: true });
      return;
    }
    buildGate();
    uncloak(); // gate itself is visible; page behind stays covered by overlay
  }

  window.FireBabysAuth = {
    getUser: function () {
      return authedUser;
    },
    getToken: getToken,
    isAuthed: function () {
      return !!authedUser;
    },
    onAuthed: function (cb) {
      if (authedUser) cb(authedUser);
      else authedCbs.push(cb);
    },
    signOut: function () {
      store(TOKEN_KEY, null);
      setUser(null);
      var b = document.querySelector(".fbbadge");
      if (b && b.parentNode) b.parentNode.removeChild(b);
      authedCbs = [];
      buildGate();
    },
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
